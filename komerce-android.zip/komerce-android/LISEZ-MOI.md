# KOMERCE : projet Android (Capacitor)

## Option A : sans ordinateur (GitHub, gratuit)
1. Créez un compte sur github.com, puis un dépôt vide « komerce-android ».
2. Envoyez-y tout le contenu de ce dossier (bouton « Add file > Upload files »),
   y compris le dossier caché `.github`.
3. Onglet « Actions » > « Build APK » > « Run workflow ».
4. Après 5 à 8 minutes, ouvrez l'exécution terminée et téléchargez `komerce-apk` (zip contenant `app-debug.apk`).
5. Sur Android, ouvrez l'APK et autorisez l'installation depuis cette source.

## Option B : avec un ordinateur
Prérequis : Node 20+, JDK 17, Android Studio.
    npm install
    npx cap add android
    npm run build:apk
L'APK se trouve dans `android/app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- Cet APK est un APK de test (debug), installable directement. Pour le Play Store, il faut un APK/AAB signé (Android Studio > Build > Generate Signed Bundle).
- L'application nécessite une connexion Internet (Supabase).
- Mettre à jour l'application : remplacez `www/index.html`, puis relancez la compilation.
- L'impression du reçu (window.print) peut ne pas fonctionner dans l'application Android.
